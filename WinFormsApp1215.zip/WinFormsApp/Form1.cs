﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

//參考：加入NPOI.dll  https://blog.csdn.net/jmh1996/article/details/78225718
using NPOI.HSSF.UserModel;  //HSSFWorkbook:是操作Excel2003以前（包括2003）的版本，扩展名是.xls 
using NPOI.XSSF.UserModel;  // from NPOI.OOXML.dll 。並且使用XSSFWorkbook還需要加入：NPOI.OpenXml4Net.dll與NPOI.OpenXmlFormats.dll
                            //ICSharpCode.SharpZipLib.dll
using NPOI.HPSF;
using NPOI.POIFS.FileSystem;
using NPOI.Util;
using NPOI.SS.UserModel;//XSSF中的XSSFWorkbook和HSSF中的HSSFWorkbook拥有的属性、方法等都是一样的,都继承同一个接口：IWorkbook
using System.Globalization;

namespace WinFormsApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label1.Text = "";
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
            label5.Text = "";
            progressBar1.Visible = false;
        }

     
        //IWorkbook myHSSFworkbook = new HSSFWorkbook();  //用于创建 .xls
        //IWorkbook myXSSFworkbook = new XSSFWorkbook();  //用于创建 .xlsx

        HSSFWorkbook book = new HSSFWorkbook(); //创新一个新的excel文件的workbook对象

        DataTable overTime_T;  //加班excel → datatabl
        DataTable accessControl_T;  //門禁
        DataTable manpower_T;    //人力
        DataTable overTimeException_T;  //加班異常及原因
        DataTable attendance_T; //考勤
        DataTable attendanceException_T;    //考勤異常及原因

       
        private string selectExcel(string theTitle)  //點擊按鈕后，彈出打開文件的對話框，選擇文件，返回文件路徑
        {
            OpenFileDialog thefileDialog = new OpenFileDialog();    //打開文件的對話框
            thefileDialog.Title = "請選擇：" + theTitle;    //設置對話框的標題
            //thefileDialog.Filter = "All(*.*)|*.*";    //過濾文件

            if (thefileDialog.ShowDialog() == DialogResult.OK)  //判斷是否有選擇某一文件
            {
                return thefileDialog.FileName;  //返回文件完整路徑
            }
            else return null;
        }


        private DataTable ExcelToDataTable(string path) //將Excel 讀取到DataTable中
        {
            //Reference: https://www.cnblogs.com/shiyh/p/7478222.html

            DataTable dataTable =null;
            DataColumn dataColumn = null;
            DataRow dataRow = null;

            //不管是读还是写一个excel文件，都要先生成一个HSSFWorkbook对象
            //NPOI里面的管理层次为：workbook->worksheet->row->cell
            IWorkbook workBook=null; 
            ISheet sheet;
            IRow row;
            ICell cell;

            try
            {
                using (FileStream fs = new FileStream(path, FileMode.Open)) 
                {
                    string fileExtension = System.IO.Path.GetExtension(path);   //返回指定路徑的文件擴展名
                    if (fileExtension.Equals(".xls"))    //判斷擴展名是否為.xls
                    {
                        workBook = new HSSFWorkbook(fs);    //读取excel文件的数据内容。 若沒有fs，則表示創建一個新的excel文件的workbook对象
                    }
                    else if(fileExtension.Equals(".xlsx"))
                    {
                        //MessageBox.Show("文件類型不是.xls");
                        workBook = new XSSFWorkbook(fs);
                    }
                }
            }

            catch(Exception e)
            {
                MessageBox.Show(e.Message);
                progressBar1.Visible = false;
            }
            


            if(workBook != null)
            {
                dataTable = new DataTable();    //實例化
                sheet = workBook.GetSheetAt(0); //讀取第一個sheet
                if(sheet !=null)
                {
                    progressBar1.Visible = true;
                    progressBar1.Minimum = 0;
                    IRow firstRow = sheet.GetRow(0);   //讀取sheet的第一行
                    //int cellCount = firstRow.LastCellNum;   //統計sheet的第一行有多少列

                    //假設sheet的第一列都是列名，不是數據。   取列名作為datatable的列名
                    for(int i = firstRow.FirstCellNum; i<firstRow.LastCellNum; i++)
                    {
                        
                        cell = firstRow.GetCell(i); //依次取第一行單元格的值
                        if(cell != null  &&  cell.StringCellValue != null)
                        {
                            dataColumn = new DataColumn(cell.StringCellValue);
                            dataTable.Columns.Add(dataColumn);
                        }
                    }

                    label5.Visible = true;
                    //建好列之後，開始填充datatable的每一行的數據
                    for (int i=1; i<=sheet.LastRowNum; i++)
                    {
                        progressBar1.Value = (i * 100 / sheet.LastRowNum);
                        progressBar1.PerformStep();
                        label5.Text = progressBar1.Value.ToString()+"%";
                        label5.Refresh();
                        row = sheet.GetRow(i);
                        if (row == null)   continue;    //如果是空行，則繼續讀取下一行
                        
                        dataRow = dataTable.NewRow();   //若不為空行，則datatable增加一行
                        for(int j=row.FirstCellNum; j< firstRow.LastCellNum; j++)
                        {
                            cell = row.GetCell(j);  //讀取當前i行j列的單元格

                            //short formatttt = cell.CellStyle.DataFormat;  //用於測試的時候查看cell單元格的格式
                          
                            if (cell == null)
                            {
                                dataRow[j] = "";    //為空的單元格
                            }
                            else
                            {
                                //cell.SetCellType(CellType.String);  //將cell的格式全部統一為 string

                                //CellType(Unknown = -1,Numeric = 0,String = 1,Formula = 2,Blank = 3,Boolean = 4,Error = 5,)
                                switch (cell.CellType)
                                {
                                    case CellType.Blank:
                                        dataRow[j] = "";    //空
                                        break;

                                    case CellType.String:
                                        dataRow[j] = cell.StringCellValue;  //字符
                                        break;

                                    //case CellType.Numeric:  //【時間讀取有bug】
                                    //    short format = cell.CellStyle.DataFormat;
                                    //    //对时间格式（2015.12.5、2015/12/5、2015-12-5等）的处理  
                                    //    if (format == 14 || format == 31 || format == 57 || format == 58)   //沒有看懂...
                                    //        dataRow[j] = cell.DateCellValue;
                                    //    else
                                    //        dataRow[j] = cell.NumericCellValue;
                                    //    break;


                                    case CellType.Numeric:  //【時間讀取有bug】
                                        short format = cell.CellStyle.DataFormat;
                                        //对时间格式（2015.12.5、2015/12/5、2015-12-5等）的处理  
                                        
                                        if (format==14)   //判斷是否為日期格式
                                        {
                                            dataRow[j] = cell.DateCellValue.ToString("yyyy/MM/dd");
                                        }
                                            
                                        else if(format==20) //判斷是否是時間格式
                                        {
                                            dataRow[j] = cell.DateCellValue.ToString("HH:mm");
                                        }
                                        else if(format == 22)
                                        {
                                            dataRow[j] = cell.DateCellValue.ToString("yyyy/MM/dd HH:mm");
                                        }
                                        else
                                            dataRow[j] = cell.ToString();
                                        break;


                                    default:    
                                        dataRow[j] = cell.StringCellValue;  //字符
                                        break;

                                }
                            }
                        }

                        dataTable.Rows.Add(dataRow);  //將dataRow 插入dataTable

                    }
                }
            }

                return dataTable;
        }



        private string saveExcel ()     //彈出保存文件的對話框設置文件路徑,返回文件路徑。文件格式有.xls與.xlsx兩種可選
        {
            string path = "";
            SaveFileDialog thefileDialog = new SaveFileDialog();
            thefileDialog.Title = "文件保存";
            thefileDialog.Filter = ".xls格式(*.xls)|*.xls|.xlsx格式(*.xlsx)|*.xlsx";
            if (thefileDialog.ShowDialog()==DialogResult.OK)
            {
                path = thefileDialog.FileName;
            }
            return path;
        }



        private bool DataTableToExcel(DataTable dt,string path)  //datatable 數據寫入excel，若寫入成功返回true, 否則false
        {
            // reference: https://www.cnblogs.com/shiyh/p/7478222.html
            bool result = false;
            IWorkbook workbook = null;
            FileStream fs = null;
            IRow row = null;
            ISheet sheet = null;
            ICell cell = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                workbook = new HSSFWorkbook();
                sheet = workbook.CreateSheet("Sheet0");//创建一个名称为Sheet0的表  
                int rowCount = dt.Rows.Count;//行数  
                int columnCount = dt.Columns.Count;//列数  

                //设置列头  
                row = sheet.CreateRow(0);//excel第一行设为列头  
                for (int c = 0; c < columnCount; c++)
                {
                    cell = row.CreateCell(c);
                    cell.SetCellValue(dt.Columns[c].ColumnName);
                }

                //從第二行開始，设置每行每列的单元格,  
                for (int i = 0; i < rowCount; i++)
                {
                    row = sheet.CreateRow(i + 1);
                    for (int j = 0; j < columnCount; j++)
                    {
                        cell = row.CreateCell(j);//excel第二行开始写入数据  
                        cell.SetCellValue(dt.Rows[i][j].ToString());
                    }
                }
                try
                {
                    using (fs = File.OpenWrite(path))
                    {
                        workbook.Write(fs);//向打开的这个xls文件中写入数据  
                        result = true;
                    }
                }
                catch(Exception e)
                {
                    //MessageBox.Show(e.ToString());  //會顯示詳細錯誤
                    MessageBox.Show(e.Message);
                    
                    //將exception詳情寫進log檔
                    //string LogAddress = Environment.CurrentDirectory + '\\' +DateTime.Now.Year + '-' +DateTime.Now.Month + '-' + DateTime.Now.Day + "_Log.log";
                    string LogAddress = Environment.CurrentDirectory + '\\' + DateTime.Now.Year + '-' + DateTime.Now.Month + "_Log.log";
                    StreamWriter fw = new StreamWriter(LogAddress, true);   //StreamWriter(string path, bool append)
                    fw.WriteLine("當前時間：" + DateTime.Now.ToString());    //取得目前日期的年月日時分秒
                    fw.WriteLine("異常信息：" + e.Message);  //取得exception的訊息
                    fw.WriteLine("異常對象：" + e.Source);   
                    fw.WriteLine("異常堆棧：" + e.StackTrace.Trim());   //取得exception發生的位置
                    fw.WriteLine("觸發方法：" + e.TargetSite);   //取得發生exception的方法
                    fw.WriteLine();
                    fw.Close();   //關閉fw之後，數據才會寫入到文件里
                }
                
            }
            
            return result;
        }



        private DataTable overTimeExceptions(DataTable dt,DataTable gateTable)   //加班異常分析
        {
            DataTable exception_T = new DataTable();
            DataColumn dataColumns = null;  //縱列
            DataRow dataRows = null;
            DataRow dataRow_E = null;

            AccessControlAnalysis gateTbAnalysis = new AccessControlAnalysis(accessControl_T);

            for (int i = 0; i<dt.Columns.Count; i++)
            {
                dataColumns = new DataColumn( dt.Columns[i].ColumnName );   //將dt的列名作為exception_T 的列名
                exception_T.Columns.Add( dataColumns );   //添加列
            }

            string[] addNew = new string[] { "原因", "責任部門", "責任人" }; //在後面再增加這3欄
            for(int a=0; a< addNew.Length; a++)
            {
                dataColumns = new DataColumn(addNew[a]);   //
                exception_T.Columns.Add(dataColumns);   //添加列
            }

            //查找加班有異常的數據，添加至exception_T 表
            //分析異常的原因--reference table:門禁記錄

            //0工号 1姓名 2部门代号 3部门名称 4日期 5排班开始时间 6排班結束时间 7第一筆刷卡 8第二筆刷卡 9第三筆刷卡 10第四筆刷卡
            //11加班開始刷卡 12加班結束刷卡 13加班开始时间 14加班结束时间 15假日別 16迟到 17早退 18旷职 19请假 20假别	
            //21正班工时 22加班工时 23加班備註 24直接/间接 25加班創建者       26原因 27責任部門  28責任人

            progressBar1.Minimum = 0;
            progressBar1.Maximum = 100;
            progressBar1.Step = 1;
            for (int x = 0; x < dt.Rows.Count; x++) //行
            {
                progressBar1.Value = (x+1) * 100 / dt.Rows.Count ;
                progressBar1.PerformStep();
                label5.Text = progressBar1.Value.ToString() + "%";
                label5.Refresh();
                dataRows = dt.Rows[x];

                #region   //07:00與19:00班別的“工作日”加班，5：00開始或17：00開始。  IDL人員工作日不算加班
                //實際加班時長theActualTime需根據“加班開始刷卡”“加班結束刷卡”計算（若是漏刷卡則根據門禁確認卡點）
                //
                

                if (dt.Rows[x][15].Equals("工作日") && (dt.Rows[x][5].Equals("07:00") | dt.Rows[x][5].Equals("19:00")))   //排班開始的時間
                {
                    //---------將datatable A 某一行 整行添加至 datatable B 
                    //dataRow_E = exception_T.NewRow();
                    //dataRow_E.ItemArray = dt.Rows[x].ItemArray;
                    //exception_T.Rows.Add(dataRow_E);

                    //AccessControlAnalysis gateTbAnalysis = new AccessControlAnalysis(accessControl_T);  //274
                    string theAccessTime;

                    if (string.IsNullOrWhiteSpace(dt.Rows[x][10].ToString())) //第四筆刷卡，空
                    {
                        if (string.IsNullOrWhiteSpace(dt.Rows[x][11].ToString()))   //加班開始刷卡，空
                        {
                            if (string.IsNullOrWhiteSpace(dt.Rows[x][12].ToString()))   //加班結束刷卡，空
                            {
                                //第四筆刷卡，空  加班上班卡(五)，空  加班下班卡(六)，空
                                // → 加班上下班卡均未刷，歸類為：未加班，不需要分析加班有沒有異常
                            }
                            else
                            {
                                //第四筆刷卡，空  加班上班卡(五)，空  加班下班卡(六)，有值
                                //查門禁：查mode=5
                                theAccessTime = gateTbAnalysis.getTime(dt.Rows[x][0].ToString(), dt.Rows[x][4].ToString(), dt.Rows[x][5].ToString(), 5);

                                dataRow_E = exception_T.NewRow(); //添加行
                                dataRow_E.ItemArray = dt.Rows[x].ItemArray;

                                dataRow_E[11] = "門禁" + theAccessTime;    //加班應刷卡時間，11加班開始刷卡
                                if (theAccessTime!= "unfound")
                                {
                                    dataRow_E[26] = "漏刷第五筆";
                                    //判斷有沒有報加班
                                    if (dt.Rows[x][22].ToString().Contains("N"))
                                    {
                                        //說明報了加班 
                                        if (TheSixth.isTimeOut(dt.Rows[x][12].ToString(), dt.Rows[x][14].ToString())) //判斷第六筆卡是否超時
                                        {
                                            dataRow_E[26] = dataRow_E[26] + "/刷卡超時";
                                        }
                                    }
                                    else
                                    {   dataRow_E[26] = dataRow_E[26] + "/漏報加班";   }
                                }
                                else
                                {
                                    dataRow_E[26] = "error";    //原因----測試用------------
                                }

                                exception_T.Rows.Add(dataRow_E);
                                //return exception_T; //這語句在這裡僅作為測試用


                                //--------篩選
                                //DataRow[] GetRows = null;
                                //GetRows= gateTable.Select( strExpr );
                                //gateDt1 = gateTable.Clone();   //复制DataTable dt结构不包含数据
                                //foreach (DataRow row in GetRows)
                                //{
                                //    gateDt1.Rows.Add(row.ItemArray);
                                //}


                            }


                        }

                        else     //加班開始刷卡，有值
                        {
                            if (string.IsNullOrWhiteSpace(dt.Rows[x][12].ToString()))   //加班結束刷卡，空
                            {
                                //第四筆刷卡，空  加班上班卡(五)，有值  加班下班卡(六)，空
                                // → 加班下班卡未刷，查門禁：查mode=6
                                theAccessTime = gateTbAnalysis.getTime(dt.Rows[x][0].ToString(), dt.Rows[x][4].ToString(), dt.Rows[x][5].ToString(), 6);
                                dataRow_E = exception_T.NewRow(); //添加行
                                dataRow_E.ItemArray = dt.Rows[x].ItemArray;
                                dataRow_E[12] = "門禁" + theAccessTime;   //12加班結束刷卡
                                if (theAccessTime != "unfound")
                                {
                                    dataRow_E[26] = "漏刷第六筆";
                                    //判斷有沒有報加班
                                    if (dt.Rows[x][22].ToString().Contains("N"))
                                    {
                                        //說明報了加班 

                                    }
                                    else
                                    { dataRow_E[26] = dataRow_E[26] + "/漏報加班"; }

                                }
                                else
                                {   dataRow_E[26] = "error";    }

                                exception_T.Rows.Add(dataRow_E);

                            }
                            else
                            {
                                //第四筆刷卡，空  加班上班卡(五)，有值  加班下班卡(六)，有值
                                //工作日加班，加班上下班卡均有值，則不需要查門禁，→ 需要判斷1.有沒有報加班&2.第六筆卡是不是超時刷卡
                                //判斷有沒有報加班
                                if (dt.Rows[x][22].ToString().Contains("N"))  //有“N”則表示工作日報了加班
                                {
                                    //說明報了加班 
                                    double overTime = 0;  //系統統計的加班時長
                                    string[] nums = dt.Rows[x][22].ToString().Split(new char[2] { 'N', ':' }, StringSplitOptions.RemoveEmptyEntries);   //工作日加班
                                    foreach (string str in nums)
                                    {
                                        overTime = overTime + Convert.ToDouble(str);
                                    }

                                    if (overTime == 0)    //若每一筆卡都正常，並且報了加班，但是系統統計的加班時長為0，則加班未進系統
                                    {
                                        dataRow_E = exception_T.NewRow(); //添加行
                                        dataRow_E.ItemArray = dt.Rows[x].ItemArray;
                                        dataRow_E[26] = "加班未進系統";
                                        exception_T.Rows.Add(dataRow_E);
                                    }


                                    //判斷第六筆卡是否超時
                                    else if (TheSixth.isTimeOut(dt.Rows[x][12].ToString(), dt.Rows[x][14].ToString())) //判斷第六筆卡是否超時
                                    {
                                        dataRow_E = exception_T.NewRow(); //添加行
                                        dataRow_E.ItemArray = dt.Rows[x].ItemArray;
                                        dataRow_E[26] =  "刷卡超時";
                                        exception_T.Rows.Add(dataRow_E);
                                    }
                                }
                                else
                                {
                                    dataRow_E = exception_T.NewRow(); //添加行
                                    dataRow_E.ItemArray = dt.Rows[x].ItemArray;
                                    dataRow_E[26] =  "漏報加班";
                                    exception_T.Rows.Add(dataRow_E);
                                }
                                
                            }

                        }


                    }

                    else      //第四筆卡，有值
                    {
                        if (string.IsNullOrWhiteSpace(dt.Rows[x][11].ToString()))   //加班開始刷卡，空
                        {
                            if (string.IsNullOrWhiteSpace(dt.Rows[x][12].ToString()))   //加班結束刷卡，空
                            {
                                //第四筆刷卡，有值  加班上班卡(五)，空  加班下班卡(六)，空
                                // → 加班上下班卡均未刷上，→ 需要判斷第四筆卡的時間是否超過04：35 或16：35。若超過，則查門禁，判斷是不是有加班
                                //0000000000000000000000000000000000000000000000000000000000000000000000000000000000
                                if ((dt.Rows[x][5].Equals("07:00") && (Convert.ToDateTime(dt.Rows[x][10]) > Convert.ToDateTime("16:35"))) | (dt.Rows[x][5].Equals("19:00") && (Convert.ToDateTime(dt.Rows[x][10]) > Convert.ToDateTime("04:35"))))
                                {

                                    string theAccessTime4 = gateTbAnalysis.getTime(dt.Rows[x][0].ToString(), dt.Rows[x][4].ToString(), dt.Rows[x][5].ToString(), 4);
                                    string theAccessTime6 = gateTbAnalysis.getTime(dt.Rows[x][0].ToString(), dt.Rows[x][4].ToString(), dt.Rows[x][5].ToString(), 6);

                                    if (theAccessTime4 != "unfound"  && theAccessTime6 != "unfound")
                                    {
                                        dataRow_E = exception_T.NewRow(); //添加行
                                        dataRow_E.ItemArray = dt.Rows[x].ItemArray;
                                        dataRow_E[11] = "打卡" + dt.Rows[x][10];    //11加班開始刷卡
                                        dataRow_E[10] = "門禁" + theAccessTime4;
                                        dataRow_E[12] = "門禁" + theAccessTime6;
                                        dataRow_E[26] = "漏刷第四筆/漏刷第六筆";
                                        //判斷有沒有報加班
                                        if (dt.Rows[x][22].ToString().Contains("N"))
                                        {
                                            //說明報了加班 
                                        }
                                        else
                                        { dataRow_E[26] = dataRow_E[26] + "/漏報加班"; }

                                        exception_T.Rows.Add(dataRow_E);
                                    }

                                    else
                                    {
                                        //找不到門禁記錄，沒加班
                                    }
                                }
                                //0000000000000000000000000000000000000000000000000000000000000000000000000000000000

                            }
                            else
                            {
                                //第四筆刷卡，有值  加班上班卡(五)，空  加班下班卡(六)，有值
                                //需要判斷第四筆卡的時間是否超過04：35 或16：35。若超過，則查mode=4, 未超過：查mode=5
                                if ((dt.Rows[x][5].Equals("07:00") && (Convert.ToDateTime(dt.Rows[x][10]) > Convert.ToDateTime("16:35"))) | (dt.Rows[x][5].Equals("19:00") && (Convert.ToDateTime(dt.Rows[x][10]) > Convert.ToDateTime("04:35"))))
                                {
                                    theAccessTime = gateTbAnalysis.getTime(dt.Rows[x][0].ToString(), dt.Rows[x][4].ToString(), dt.Rows[x][5].ToString(), 4);
                                    dataRow_E = exception_T.NewRow(); //添加行
                                    dataRow_E.ItemArray = dt.Rows[x].ItemArray;

                                    if (theAccessTime != "unfound")
                                    {
                                        dataRow_E[11] = "打卡" + dt.Rows[x][10];    //11加班開始刷卡
                                        dataRow_E[10] = "門禁" + theAccessTime;  //正班下班卡
                                        dataRow_E[26] = "漏刷第四筆";    //原因----測試用------------

                                        //判斷有沒有報加班
                                        if (dt.Rows[x][22].ToString().Contains("N"))
                                        {
                                            //說明報了加班 
                                            if (TheSixth.isTimeOut(dt.Rows[x][12].ToString(), dt.Rows[x][14].ToString())) //判斷第六筆卡是否超時
                                            {
                                                dataRow_E[26] = dataRow_E[26] + "/刷卡超時";
                                            }
                                        }
                                        else
                                        { dataRow_E[26] = dataRow_E[26] + "/漏報加班"; }
                                        
                                    }

                                    else
                                    {
                                        theAccessTime = gateTbAnalysis.getTime(dt.Rows[x][0].ToString(), dt.Rows[x][4].ToString(), dt.Rows[x][5].ToString(), 5);
                                        dataRow_E[11] = "門禁" + theAccessTime;  //11加班開始刷卡
                                        if (theAccessTime != "unfound")
                                        {
                                            dataRow_E[26] = "漏刷第五筆";    //原因----測試用------------

                                            //判斷有沒有報加班
                                            if (dt.Rows[x][22].ToString().Contains("N"))
                                            {
                                                //說明報了加班 
                                                if (TheSixth.isTimeOut(dt.Rows[x][12].ToString(), dt.Rows[x][14].ToString())) //判斷第六筆卡是否超時
                                                {
                                                    dataRow_E[26] = dataRow_E[26] + "/刷卡超時";
                                                }
                                            }
                                            else
                                            { dataRow_E[26] = dataRow_E[26] + "/漏報加班"; }
                                        }

                                        else
                                        { dataRow_E[26] = "error"; }
                                        
                                    }
                                    exception_T.Rows.Add(dataRow_E);
                                }

                                //第四筆卡刷卡時間并未超過四點三十五，第五筆卡沒有值，第六筆卡有值，查第五筆卡的門禁
                                else
                                {
                                    theAccessTime = gateTbAnalysis.getTime(dt.Rows[x][0].ToString(), dt.Rows[x][4].ToString(), dt.Rows[x][5].ToString(), 5);
                                    dataRow_E = exception_T.NewRow(); //添加行
                                    dataRow_E.ItemArray = dt.Rows[x].ItemArray;

                                    dataRow_E[11] = "門禁" + theAccessTime;    //11加班開始刷卡
                                    if (theAccessTime != "unfound")
                                    {
                                        dataRow_E[26] = "漏刷第五筆";    //原因----測試用------------

                                        //判斷有沒有報加班
                                        if (dt.Rows[x][22].ToString().Contains("N"))
                                        {
                                            //說明報了加班 
                                            if (TheSixth.isTimeOut(dt.Rows[x][12].ToString(), dt.Rows[x][14].ToString())) //判斷第六筆卡是否超時
                                            {
                                                dataRow_E[26] = dataRow_E[26] + "/刷卡超時";
                                            }
                                        }
                                        else
                                        { dataRow_E[26] = dataRow_E[26] + "/漏報加班"; }
                                    }

                                    else
                                    { dataRow_E[26] = "error"; }
                                    
                                    exception_T.Rows.Add(dataRow_E);
                                }
                            }
                        }

                        else     //第四筆卡有值，加班開始刷卡，有值
                        {
                            if (string.IsNullOrWhiteSpace(dt.Rows[x][12].ToString()))   //加班結束刷卡，空
                            {
                                //第四筆刷卡，有值  加班上班卡(五)，有值  加班下班卡(六)，空
                                // → 加班下班卡未刷，查門禁：查mode=6
                                theAccessTime = gateTbAnalysis.getTime(dt.Rows[x][0].ToString(), dt.Rows[x][4].ToString(), dt.Rows[x][5].ToString(), 6);
                                dataRow_E = exception_T.NewRow(); //添加行
                                dataRow_E.ItemArray = dt.Rows[x].ItemArray;
                                dataRow_E[12] = "門禁" + theAccessTime;    //12加班下班卡

                                if (theAccessTime != "unfound")
                                {
                                    dataRow_E[26] = "漏刷第六筆";    //原因----測試用------------

                                    //判斷有沒有報加班
                                    if (dt.Rows[x][22].ToString().Contains("N"))
                                    {
                                        //說明報了加班 
                                    }
                                    else
                                    { dataRow_E[26] = dataRow_E[26] + "/漏報加班"; }
                                }

                                else
                                { dataRow_E[26] = "error"; }
                                
                                exception_T.Rows.Add(dataRow_E);

                            }
                            else
                            {
                                //第四筆刷卡，有值  加班上班卡(五)，有值  加班下班卡(六)，有值
                                //工作日加班，加班上下班卡均有值，則不需要查門禁，→ 需要判斷1.有沒有報加班&2.第六筆卡是不是超時刷卡
                                //判斷有沒有報加班
                                if (dt.Rows[x][22].ToString().Contains("N"))  //有“N”則表示工作日報了加班
                                {
                                    //說明報了加班 
                                    double overTime = 0;  //系統統計的加班時長
                                    string[] nums = dt.Rows[x][22].ToString().Split(new char[2] { 'N', ':' }, StringSplitOptions.RemoveEmptyEntries);   //工作日加班
                                    foreach (string str in nums)
                                    {
                                        overTime = overTime + Convert.ToDouble(str);
                                    }

                                    if (overTime == 0)    //若每一筆卡都正常，並且報了加班，但是系統統計的加班時長為0，則加班未進系統
                                    {
                                        dataRow_E = exception_T.NewRow(); //添加行
                                        dataRow_E.ItemArray = dt.Rows[x].ItemArray;
                                        dataRow_E[26] = "加班未進系統";
                                        exception_T.Rows.Add(dataRow_E);
                                    }


                                    //判斷第六筆卡是否超時
                                    else if (TheSixth.isTimeOut(dt.Rows[x][12].ToString(), dt.Rows[x][14].ToString())) //判斷第六筆卡是否超時
                                    {
                                        dataRow_E = exception_T.NewRow(); //添加行
                                        dataRow_E.ItemArray = dt.Rows[x].ItemArray;
                                        dataRow_E[26] = "刷卡超時";
                                        exception_T.Rows.Add(dataRow_E);
                                    }

                                    else
                                    {
                                        //報了加班，並且刷卡也沒有超時 → 計算工時是否一致？正常：加班未進系統
                                        if (ReasonAnalysis.getResult(dt.Rows[x][11].ToString(), dt.Rows[x][12].ToString(), dt.Rows[x][22].ToString()).Equals("加班工時不一致"))
                                        {
                                            dataRow_E = exception_T.NewRow(); //添加行
                                            dataRow_E.ItemArray = dt.Rows[x].ItemArray;
                                            int countN = dt.Rows[x][22].ToString().Length - dt.Rows[x][22].ToString().Replace("N:", "N").Length;    //統計報了幾筆加班
                                            if (countN == 2)
                                            {
                                                dataRow_E[26] = "其中一筆加班未進系統";
                                            }
                                            else
                                            {
                                                dataRow_E[26] = "漏報一筆加班";
                                            }
                                            exception_T.Rows.Add(dataRow_E);
                                        }
                                    }
                                }
                                else
                                {
                                    dataRow_E = exception_T.NewRow(); //添加行
                                    dataRow_E.ItemArray = dt.Rows[x].ItemArray;
                                    dataRow_E[26] = "漏報加班";
                                    exception_T.Rows.Add(dataRow_E);
                                }
                            }

                        }
                    }


                }   // 工作日，排班為07：00  19：00 的

                #endregion


                #region    //“例假日”加班，要麼打兩筆卡（八點班別和七點班別），要麼打四筆卡（七點班別）
                if (dt.Rows[x][15].Equals("例假日"))
                {
                    string theAccessTime;
                    bool partOneException = false;
                    dataRow_E = exception_T.NewRow(); //添加行
                    dataRow_E.ItemArray = dt.Rows[x].ItemArray;
                    //001-------------------------------------------------------------------------------------------------------
                    if (string.IsNullOrWhiteSpace(dt.Rows[x][7].ToString())) //第一筆刷卡，空
                    {
                        if (string.IsNullOrWhiteSpace(dt.Rows[x][10].ToString())) //第四筆刷卡，空
                        {
                            //第一筆卡，空     第四筆卡，空
                            //當做無異常
                        }

                        else
                        {
                            //第一筆卡，空     第四筆卡，有值
                            //查詢門禁確認第 1 筆卡
                            //dataRow_E = exception_T.NewRow(); //添加行
                            //dataRow_E.ItemArray = dt.Rows[x].ItemArray;  //368
                            theAccessTime = gateTbAnalysis.getTime(dt.Rows[x][0].ToString(), dt.Rows[x][4].ToString(), dt.Rows[x][5].ToString(), 1);
                            partOneException = true;
                            dataRow_E[7] = "門禁" + theAccessTime;    //應刷卡時間，7第一筆刷卡
                            if (theAccessTime != "unfound")
                            {
                                dataRow_E[26] = "漏刷第一筆";  //26原因
                                //判斷有沒有報加班
                                if (dt.Rows[x][22].ToString().Contains("S"))  //22加班工时
                                {
                                    //說明報了加班 
                                }
                                else
                                { dataRow_E[26] = dataRow_E[26] + "/漏報加班"; }
                            }
                            else
                            {
                                dataRow_E[26] = "error";    //原因----測試用------------
                            }
                        }
                    }

                    else    //第一筆刷卡，有值
                    {
                        if (string.IsNullOrWhiteSpace(dt.Rows[x][10].ToString())) //第四筆刷卡，空
                        {
                            //第一筆卡，有值     第四筆卡，空
                            //查詢門禁確認第 4 筆卡
                            theAccessTime = gateTbAnalysis.getTime(dt.Rows[x][0].ToString(), dt.Rows[x][4].ToString(), dt.Rows[x][5].ToString(), 4);
                            partOneException = true;
                            dataRow_E[10] = "門禁" + theAccessTime;    //應刷卡時間，10第四筆刷卡
                            if (theAccessTime != "unfound")
                            {
                                dataRow_E[26] = "漏刷第四筆";  //26原因
                                //判斷有沒有報加班
                                if (dt.Rows[x][22].ToString().Contains("S"))   //22加班工时
                                {
                                    //說明報了加班 
                                }
                                else
                                { dataRow_E[26] = dataRow_E[26] + "/漏報加班"; }
                            }
                            else
                            {
                                dataRow_E[26] = "error";    //原因----測試用------------
                            }
                        }

                        else
                        {
                            //第一筆卡，有值     第四筆卡，有值
                            //例假加班，正班上下班卡均有值，則不需要查門禁，→ 需要判斷1.有沒有報加班&2.加班有沒有進系統
                            //判斷有沒有報加班
                            if (dt.Rows[x][22].ToString().Contains("S"))  //有“N”則表示工作日報了加班
                            {
                                //說明報了加班 
                                double overTime = 0;  //系統統計的加班時長
                                string[] nums = dt.Rows[x][22].ToString().Split(new char[2] { 'S', ':' }, StringSplitOptions.RemoveEmptyEntries);   //工作日加班
                                foreach (string str in nums)
                                {
                                    overTime = overTime + Convert.ToDouble(str);
                                }

                                if (overTime == 0)    //若每一筆卡都正常，並且報了加班，但是系統統計的加班時長為0，則加班未進系統
                                {
                                    partOneException = true;
                                    dataRow_E[26] = "加班未進系統";
                                }
                            }
                            else
                            {
                                partOneException = true;
                                dataRow_E[26] = "漏報加班";
                            }
                        }
                    }
                    //002---------------------------------------------------------------------------------------------------------
                    if (string.IsNullOrWhiteSpace(dt.Rows[x][11].ToString())) //第五筆刷卡，空
                    {
                        if (string.IsNullOrWhiteSpace(dt.Rows[x][12].ToString())) //第六筆刷卡，空
                        {
                            //第五筆卡，空     第六筆卡，空  
                            //第五、六筆卡無異常，仍需確認第一7、第四10筆卡是否有異常，若有異常，則添加至exception_T表
                            if (partOneException)  //異常
                            {
                                exception_T.Rows.Add(dataRow_E);  
                            }
                        }

                        else
                        {
                            //第五筆卡，空     第六筆卡，有值
                            //查詢門禁確認第 5 筆卡
                            theAccessTime = gateTbAnalysis.getTime(dt.Rows[x][0].ToString(), dt.Rows[x][4].ToString(), dt.Rows[x][5].ToString(), 5);

                            dataRow_E[11] = "門禁" + theAccessTime;    //應刷卡時間，11第五筆刷卡
                            if (theAccessTime != "unfound")
                            {
                                dataRow_E[26] = dataRow_E[26] + "漏刷第五筆";  //26原因
                                //判斷有沒有報加班
                                if (dt.Rows[x][22].ToString().Contains("S"))  //22加班工时
                                {
                                    //說明報了加班 
                                    if (TheSixth.isTimeOut(dt.Rows[x][12].ToString(), dt.Rows[x][14].ToString())) //判斷第六筆卡是否超時
                                    {
                                        dataRow_E[26] = dataRow_E[26] + "/刷卡超時";
                                    }
                                }
                                else
                                { dataRow_E[26] = dataRow_E[26] + "/漏報加班"; }
                            }
                            else
                            {
                                dataRow_E[26] = dataRow_E[26] + "error";    //原因----測試用------------
                            }
                            exception_T.Rows.Add(dataRow_E);  
                        }
                    }

                    else    //第五筆刷卡，有值
                    {
                        if (string.IsNullOrWhiteSpace(dt.Rows[x][12].ToString())) //第六筆刷卡，空
                        {
                            //第五筆卡，有值     第六筆卡，空
                            //查詢門禁確認第 6 筆卡
                            theAccessTime = gateTbAnalysis.getTime(dt.Rows[x][0].ToString(), dt.Rows[x][4].ToString(), dt.Rows[x][5].ToString(), 6);

                            dataRow_E[12] = "門禁" + theAccessTime;    //應刷卡時間，12第六筆刷卡
                            if (theAccessTime != "unfound")
                            {
                                dataRow_E[26] = dataRow_E[26] + "漏刷第六筆";  //26原因
                                //判斷有沒有報加班
                                if (dt.Rows[x][22].ToString().Contains("S"))   //22加班工时
                                {
                                    //說明報了加班 
                                }
                                else
                                { dataRow_E[26] = dataRow_E[26] + "/漏報加班"; }
                            }
                            else
                            {
                                dataRow_E[26] = dataRow_E[26] + "error";    //原因----測試用------------
                            }
                            exception_T.Rows.Add(dataRow_E);
                        }

                        else
                        {
                            //第五筆卡，有值     第六筆卡，有值
                            //例假日加班，第五、第六筆卡均有值，需要先判斷有沒有報加班，再判斷第六筆卡是不是刷卡超時，超時則為異常
                            //若沒有超時，則第一部份（第一、第四筆）是否有異常，有異常則添加至exception_T表
                            //判斷有沒有報加班
                            if (dt.Rows[x][22].ToString().Contains("S"))  //22加班工时
                            {
                                //說明報了加班 
                                double overTime = 0;  //系統統計的加班時長
                                string[] nums = dt.Rows[x][22].ToString().Split(new char[2] { 'S', ':' }, StringSplitOptions.RemoveEmptyEntries);   //工作日加班
                                foreach (string str in nums)
                                {
                                    overTime = overTime + Convert.ToDouble(str);
                                }

                                if (overTime == 0)    //若每一筆卡都正常，並且報了加班，但是系統統計的加班時長為0，則加班未進系統
                                {
                                    dataRow_E[26] = dataRow_E[26] + "/加班未進系統";
                                    exception_T.Rows.Add(dataRow_E);
                                }
                                
                                //判斷第六筆卡是否超時
                                else if (TheSixth.isTimeOut(dt.Rows[x][12].ToString(), dt.Rows[x][14].ToString())) //判斷第六筆卡是否超時
                                {
                                    dataRow_E[26] = dataRow_E[26] + "/刷卡超時";
                                    exception_T.Rows.Add(dataRow_E);
                                }

                                else if(partOneException)
                                {
                                    exception_T.Rows.Add(dataRow_E);
                                }
                            }
                            else
                            {
                                dataRow_E[26] = dataRow_E[26] + "/漏報加班";
                                exception_T.Rows.Add(dataRow_E);
                            }

                        }
                    }

                    //-------------------------------------------------------
                }

                #endregion
            }



            return exception_T;
        }




        private DataTable attendanceExceptions(DataTable dt)   //考勤異常分析
        {
            DataTable exception_T = new DataTable();
            DataColumn dataColumns = null;
            DataRow dataRows = null;
            DataRow dataRow_E = null;
            AccessControlAnalysis gateTbAnalysis = new AccessControlAnalysis(accessControl_T);

            for (int i = 0; i < dt.Columns.Count; i++)
            {
                dataColumns = new DataColumn(dt.Columns[i].ColumnName);   //將dt的列名作為exception_T 的列名
                exception_T.Columns.Add(dataColumns);   //添加列
            }

            string[] addNew = new string[] { "原因", "責任部門", "責任人" }; //在後面再增加這3欄
            for (int a = 0; a < addNew.Length; a++)
            {
                dataColumns = new DataColumn(addNew[a]);   //
                exception_T.Columns.Add(dataColumns);   //添加列
            }


            //遍歷每一行，判斷是否屬於異常
            for (int x = 0; x < dt.Rows.Count; x++) //行
            {
                progressBar1.Value = (x+1) * 100 / dt.Rows.Count;   //進度條數值
                progressBar1.PerformStep();     //進度條前移
                label5.Text = progressBar1.Value.ToString() + "%";  //標籤顯示進度百分比
                label5.Refresh();   //更新標籤
                //0員工編號 1員工姓名 2部門編號 3部門名稱 4到職日期 5離職日期 6日期 7假別 8假別名稱 9請假開始 10請假結束	
                //11天數 12時數 13應勤上班 14應勤下班 15上班時間 16下班時間  17原因  18責任部門  19責任人
                if (string.IsNullOrWhiteSpace(dt.Rows[x][5].ToString())) //5離職日期，空：未跑離職單的
                {
                    if (dt.Rows[x][8].Equals("遲到")  | dt.Rows[x][8].Equals("早退"))  //上下班卡均有值  
                    {
                        dataRow_E = exception_T.NewRow(); //添加行
                        dataRow_E.ItemArray = dt.Rows[x].ItemArray;
                        
                        exception_T.Rows.Add(dataRow_E);
                    }

                    //else if (dt.Rows[x][8].Equals("早退"))  //上下班卡均有值  
                    //{
                    //    dataRow_E = exception_T.NewRow(); //添加行
                    //    dataRow_E.ItemArray = dt.Rows[x].ItemArray;
                        
                    //    exception_T.Rows.Add(dataRow_E);
                    //}

                    else if (dt.Rows[x][8].Equals("曠工"))  //上下班卡有：00、01、10、11
                    {
                        //00:查門禁
                        //01:查門禁
                        //10:查門禁
                        //11:若遲到或早退時長超過30min則算曠工。
                        dataRow_E = exception_T.NewRow(); //添加行
                        dataRow_E.ItemArray = dt.Rows[x].ItemArray;

                        
                        if (string.IsNullOrWhiteSpace(dt.Rows[x][15].ToString()))  //15上班時間
                        {
                            string[] startTimeArray = dt.Rows[x][13].ToString().Split(' ');  //13應勤上班，從“2020/11/17 07:00”提取排班開始的時間
                            string startTime = Convert.ToDateTime(startTimeArray[1]).ToString("HH:mm");
                            string theTimeIn = gateTbAnalysis.getTime(dt.Rows[x][0].ToString(), dt.Rows[x][6].ToString(), startTime, 1); //0員工編號 6日期
                            dataRow_E[15] = "門禁" + theTimeIn;
                        }

                        if (string.IsNullOrWhiteSpace(dt.Rows[x][16].ToString()) )  //16下班時間
                        {
                            string[] startTimeArray = dt.Rows[x][13].ToString().Split(' ');  //13應勤上班，從“2020/11/17 07:00”提取排班開始的時間
                            string startTime = Convert.ToDateTime(startTimeArray[1]).ToString("HH:mm");
                            string theTimeIn = gateTbAnalysis.getTime(dt.Rows[x][0].ToString(), dt.Rows[x][6].ToString(), startTime, 4); //0員工編號 6日期
                            dataRow_E[16] = "門禁" + theTimeIn;
                        }

                        exception_T.Rows.Add(dataRow_E);
                    }
                }

            }


            return exception_T;
        }
     




        //----------------------------------------------------------------------------------------
        //----------------------------------分割線------------------------------------------------------
        //----------------------------------------------------------------------------------------
        private void button1_Click(object sender, EventArgs e)  //導入加班報表
        {
            //點擊按鈕后，打開對話框，選擇文件，返回文件路徑
            label1.Text = selectExcel("導入加班報表") ;
            label1.ForeColor = Color.Blue;
            label5.Text = "";
            
            //if(label1.Text.Trim() !="")
            //{
            //    overTime_T = ExcelToDataTable(label1.Text);  //加班excel → datatabl
            //    dataGridView1.DataSource = overTime_T;  //dataGridView1 數據源綁定datatable
            //}
            overTime_T = ExcelToDataTable(label1.Text);  //加班excel → datatabl
            dataGridView1.DataSource = overTime_T;  //dataGridView1 數據源綁定datatable
        }

        private void button2_Click(object sender, EventArgs e)  //導入考勤報表
        {
            //點擊按鈕后，打開對話框，選擇文件，返回文件路徑
            label2.Text = selectExcel("導入考勤報表");
            label2.ForeColor = Color.Blue;
            label5.Text = "";
            attendance_T = ExcelToDataTable(label2.Text);
            dataGridView1.DataSource = attendance_T;
        }

        private void button3_Click(object sender, EventArgs e)  //導入門禁記錄
        {
            //點擊按鈕后，打開對話框，選擇文件，返回文件路徑
            label3.Text = selectExcel("導入門禁記錄");
            label3.ForeColor = Color.Blue;
            label5.Text = "";
            accessControl_T = ExcelToDataTable(label3.Text);
            dataGridView1.DataSource = accessControl_T;
        }

        private void button4_Click(object sender, EventArgs e)  //導入人力名單
        {
            //------------------------------
            //導入人力名單出現報錯：wrong local header signature:0xe011cfd0
            
            //label4.Text = selectExcel("導入人力名單"); //點擊按鈕后，打開對話框，選擇文件，返回文件路徑
            //manpower_T = ExcelToDataTable(label4.Text);
            //dataGridView1.DataSource = manpower_T;
            //------------------------------

            //*********************************
            label4.Text = "暫不能導入";
            label4.ForeColor = Color.Red;
            //*********************************
        }

        private void button5_Click(object sender, EventArgs e)  //加班分析
        {
            //加班異常分析
            if (label1.Text.Equals("label1") | label3.Text.Equals("label3") | label1.Text.Equals("") | label3.Text.Equals(""))
            {
                label5.Text = "請導入加班報表與門禁報表";
                label5.ForeColor = Color.Red;
            }
            else
            {
                overTimeException_T = overTimeExceptions(overTime_T, accessControl_T);  //加班報表、門禁記錄
                dataGridView1.DataSource = overTimeException_T;
                label5.Text = "加班分析結束";
                label5.ForeColor = Color.Green;
            }

        }

        private void button6_Click(object sender, EventArgs e)  //考勤分析
        {
            //考勤異常分析
            if (label2.Text.Equals("label2") | label3.Text.Equals("label3") | label2.Text.Equals("") | label3.Text.Equals(""))
            {
                label5.Text = "請導入考勤報表與門禁報表";
                label5.ForeColor = Color.Red;
            }
            else
            {
                attendanceException_T = attendanceExceptions(attendance_T);  //考勤報表、門禁記錄
                dataGridView1.DataSource = attendanceException_T;
                label5.Text = "考勤分析結束";
                label5.ForeColor = Color.Green;
            }

        }
        private void button7_Click(object sender, EventArgs e)  // 将dataGridview所显示的数据存储至excel
        {
            //導出Excel
            //label5.Text = saveExcel();  //測試用
            
            DataTable dt = new DataTable();
            dt = dataGridView1.DataSource as DataTable; //将dataGridview绑定的数据源 格式转换为datatable
            if(dt != null)
            {
                string path = saveExcel();  //path:保存文件的路径

                if (DataTableToExcel(dt, path))   //将datatable存储至excel,存放路径为path,若datatable有数据，并成功存储则返回true,否则false
                {
                    label5.Text = "保存成功";
                    label5.ForeColor = Color.Blue;
                }

                else
                {
                    label5.Text = "未保存成功";
                    label5.ForeColor = Color.Red;
                }
            }

            else
            {
                label5.Text = "没有数据可以保存";
                label5.ForeColor = Color.Red;
            }
            
        }

    }
}
