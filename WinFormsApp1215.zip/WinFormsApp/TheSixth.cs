﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinFormsApp
{
    class TheSixth
    {
        public static bool isTimeOut(string theSixCard, string EndTime) //第六筆卡正常刷上（12有值）&& 報了加班（14有值）
        {
            //                             第六筆卡的時間       系統加班結束時間 格式："19:00", "19:00/21:00","21:00/19:00"
            bool result = false; //false則表示沒有超時刷卡
            string[] theEndTime = EndTime.Split('/');   //若有“/”，則以此符號分割
            Array.Sort(theEndTime); //對數組的元素進行排序，升序
            string[] theHour = theEndTime[theEndTime.Length - 1].Split(':');    //取系統最晚的加班結束時間，分割為“時”與“分”
            DateTime theLast = Convert.ToDateTime(theHour[0] + ":" + "30");     //若第六筆卡打卡時間超過加班結束時間半個小時，則屬於【超時刷卡】
            if (Convert.ToDateTime(theSixCard) >= theLast)
            {
                //超時刷卡
                result = true;  //true則表示超時刷卡
                return result;
            }
            return result;
        }

    }
}
