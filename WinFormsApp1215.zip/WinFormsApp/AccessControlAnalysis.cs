﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Globalization;

namespace WinFormsApp
{
    class AccessControlAnalysis
    {

        public AccessControlAnalysis(DataTable accessControl_T)
        {
            gateTable = accessControl_T;
        }

        DataTable gateTable;  //門禁

          
        public string getTime(string num, string date, string workStart, int mode)
        {
                  //門禁記錄      員工工號       日期       排班開始時間   查詢第幾筆卡：


            string result = "unfound";

            //查門禁
            //DataTable筛选，
            //排序返回符合条件行组成的新DataTable
            DataTable gateDt1 = new DataTable();


            DateTime ddt;   //string格式的日期时间字符串转为DateTime类型
            DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "yyyy/MM/dd";
            ddt = Convert.ToDateTime(date, dtFormat);   //4日期

            //string dateStr1 = ddt.ToString("MM/dd/yyyy");   //日期格式由2020/10/28   轉為10/28/2020  
            string dateStr1 = date;
            string dateStr2 = "";

            string strExpr = "";
            if (workStart.Equals("19:00"))  //夜班
            {
                //string dateStr2 = ddt.AddDays(1).ToString("MM/dd/yyyy");    //日期加一天（夜班的刷卡記錄需要參考第二天的）
                dateStr2 = ddt.AddDays(1).ToString("yyyy/MM/dd");
                strExpr = "工號='" + num + "'and (門衛編號='門衛2' or 門衛編號='門衛3')" + "and (刷卡時間 like '" + dateStr1 + "%' or 刷卡時間 like '" + dateStr2 + "%')";
            }
            else
            {
                strExpr = "工號='" + num + "'and (門衛編號='門衛2' or 門衛編號='門衛3')" + "and (刷卡時間 like '" + dateStr1 + "%')";
            }


            //  08:00 班別的
            if (workStart.Equals("08:00"))
            {
                if (gateTable.Select(strExpr).Length > 0)
                {
                    //--------------------------------------------------------
                    if (mode == 1)    //上班卡未打，查詢查詢進廠區的時間
                    {
                        #region  
                        for (int ii = gateDt1.Rows.Count-1; ii >=0 ; ii--)
                        {
                            if (gateDt1.Rows[ii][7].Equals("I"))     //gateDt1.Rows[ii][7] 是門禁進出狀況,O為出去
                            {
                                string[] dateAndTime = gateDt1.Rows[ii][4].ToString().Split(' ');   //gateDt1.Rows[ii][4] 是門禁刷卡時間，格式：10/29/2020 11:12:17
                                DateTime time_1 = Convert.ToDateTime(dateAndTime[1]);  //dateAndTime[1].ToString("HH:mm")

                                //上午進來的時間
                                result = time_1.ToString("HH:mm");
                                return result;

                            }
                        }
                        #endregion
                    }

                    //--------------------------------------------------------
                    if (mode == 4)    //下班卡未打，查詢其下午出廠區的時間
                    {
                        #region  
                        for (int ii = 0; ii < gateDt1.Rows.Count; ii++)
                        {
                            if (gateDt1.Rows[ii][7].Equals("O"))     //gateDt1.Rows[ii][7] 是門禁進出狀況,O為出去
                            {
                                string[] dateAndTime = gateDt1.Rows[ii][4].ToString().Split(' ');   //gateDt1.Rows[ii][4] 是門禁刷卡時間，格式：10/29/2020 11:12:17
                                DateTime time_1 = Convert.ToDateTime(dateAndTime[1]);  //dateAndTime[1].ToString("HH:mm")

                                //下午出去的時間
                                result = time_1.ToString("HH:mm");
                                return result;
                            }
                        }
                        #endregion
                    }

                }
            }


            //  否則為 07：00  19：00 班別的
            else
            {
                if (gateTable.Select(strExpr).Length > 0)   //若工號為num 的員工在日期為date 的這一天，有門禁記錄則查詢分析，無門禁記錄則返回unfound
                {
                    gateDt1 = gateTable.Select(strExpr).CopyToDataTable();  //將查詢出來符合條件的數據添加至datatable  p.s.要是查詢結果為空則會報錯,所以要先判斷
                                                                            //然後根據門禁數據，確定該員工需要補哪筆卡

                    //--------------------------------------------------------
                    if (mode == 1)    //正班上班卡未打，查詢查詢進廠區的時間
                    {
                        #region  
                        for (int ii = 0; ii < gateDt1.Rows.Count; ii++)
                        {
                            if (gateDt1.Rows[ii][7].Equals("I"))     //gateDt1.Rows[ii][7] 是門禁進出狀況,O為出去
                            {
                                string[] dateAndTime = gateDt1.Rows[ii][4].ToString().Split(' ');   //gateDt1.Rows[ii][4] 是門禁刷卡時間，格式：10/29/2020 11:12:17
                                DateTime time_1 = Convert.ToDateTime(dateAndTime[1]);  //dateAndTime[1].ToString("HH:mm")


                                if (workStart.Equals("07:00"))  //白班
                                {
                                    //上午進來的時間
                                    if (DateTime.Compare(time_1, Convert.ToDateTime("06:00")) > 0 && DateTime.Compare(time_1, Convert.ToDateTime("10:00")) < 0)    //DateTime.Compare(t1,t2)>0,則表示t1>t2
                                    {
                                        result = time_1.ToString("HH:mm");
                                        return result;
                                    }
                                }


                                if (workStart.Equals("19:00"))  //夜班
                                {
                                    //夜班查兩天的數據，上班時間：查當天的    下班時間：查後一天的
                                    if (dateAndTime[0].Equals(dateStr1))
                                    {
                                        if (DateTime.Compare(time_1, Convert.ToDateTime("18:00")) > 0 && DateTime.Compare(time_1, Convert.ToDateTime("22:00")) < 0)    //DateTime.Compare(t1,t2)>0,則表示t1>t2
                                        {
                                            result = time_1.ToString("HH:mm");
                                            return result;
                                        }
                                    }
                                    else
                                    {
                                        continue;
                                    }
                                }
                            }
                        }
                        #endregion
                    }

                    //--------------------------------------------------------
                    if (mode == 4)    //正班下班卡未打，查詢其下午出廠區的時間
                    {
                        #region  
                        for (int ii = 0; ii < gateDt1.Rows.Count; ii++)
                        {
                            if (gateDt1.Rows[ii][7].Equals("O"))     //gateDt1.Rows[ii][7] 是門禁進出狀況,O為出去
                            {
                                string[] dateAndTime = gateDt1.Rows[ii][4].ToString().Split(' ');   //gateDt1.Rows[ii][4] 是門禁刷卡時間，格式：10/29/2020 11:12:17
                                DateTime time_1 = Convert.ToDateTime(dateAndTime[1]);  //dateAndTime[1].ToString("HH:mm")


                                if (workStart.Equals("07:00"))  //白班
                                {
                                    //下午出去的時間
                                    if (DateTime.Compare(time_1, Convert.ToDateTime("15:10")) > 0 && DateTime.Compare(time_1, Convert.ToDateTime("17:00")) < 0)    //DateTime.Compare(t1,t2)>0,則表示t1>t2
                                    {
                                        result = time_1.ToString("HH:mm");
                                        return result;
                                    }
                                }


                                if (workStart.Equals("19:00"))  //夜班
                                {
                                    //夜班查兩天的數據，上班時間：查當天的    下班時間：查後一天的
                                    if (dateAndTime[0].Equals(dateStr2))
                                    {
                                        if (DateTime.Compare(time_1, Convert.ToDateTime("03:10")) > 0 && DateTime.Compare(time_1, Convert.ToDateTime("05:00")) < 0)    //DateTime.Compare(t1,t2)>0,則表示t1>t2
                                        {
                                            result = time_1.ToString("HH:mm");
                                            return result;
                                        }
                                    }
                                        
                                }
                            }
                        }
                        #endregion
                    }

                    //--------------------------------------------------------
                    if (mode == 5)    //加班上班卡未打，查詢進入廠區的時間
                    {
                        #region  
                        for (int ii = 0; ii < gateDt1.Rows.Count; ii++)
                        {
                            if (gateDt1.Rows[ii][7].Equals("I"))     //gateDt1.Rows[ii][7] 是門禁進出狀況,I為進入
                            {
                                string[] dateAndTime = gateDt1.Rows[ii][4].ToString().Split(' ');   //gateDt1.Rows[ii][4] 是門禁刷卡時間，格式：10/29/2020 11:12:17
                                DateTime time_1 = Convert.ToDateTime(dateAndTime[1]);  //dateAndTime[1].ToString("HH:mm")

                                DateTime time_2;
                                DateTime time_3;

                                if (workStart.Equals("07:00"))  //白班加班時段
                                {
                                    time_2 = Convert.ToDateTime("15:00");
                                    time_3 = Convert.ToDateTime("19:00");
                                    if (DateTime.Compare(time_1, time_2) > 0 && DateTime.Compare(time_1, time_3) < 0)    //DateTime.Compare(t1,t2)>0,則表示t1>t2
                                    {
                                        result = time_1.ToString("HH:mm");
                                        return result;
                                    }
                                }


                                if (workStart.Equals("19:00"))  //夜班加班時段
                                {
                                    //夜班查兩天的數據，上班時間：查當天的    下班時間：查後一天的
                                    if (dateAndTime[0].Equals(dateStr2))
                                    {
                                        if (DateTime.Compare(time_1, Convert.ToDateTime("03:00")) > 0 && DateTime.Compare(time_1, Convert.ToDateTime("07:00")) < 0)    //DateTime.Compare(t1,t2)>0,則表示t1>t2
                                        {
                                            result = time_1.ToString("HH:mm");
                                            return result;
                                        }
                                    }
                                        
                                }



                            }
                        }
                        #endregion


                    }

                    //--------------------------------------------------------
                    if (mode == 6)    //加班下班卡未打，查詢出廠區的時間（報加班的一般07：00/19：00加班結束，超時加班的...）
                    {
                        #region  
                        for (int ii = 0; ii < gateDt1.Rows.Count; ii++)
                        {
                            if (gateDt1.Rows[ii][7].Equals("O"))     //gateDt1.Rows[ii][7] 是門禁進出狀況,O為出去
                            {
                                string[] dateAndTime = gateDt1.Rows[ii][4].ToString().Split(' ');   //gateDt1.Rows[ii][4] 是門禁刷卡時間，格式：10/29/2020 11:12:17
                                DateTime time_1 = Convert.ToDateTime(dateAndTime[1]);  //dateAndTime[1].ToString("HH:mm")


                                if (workStart.Equals("07:00"))  //白班
                                {
                                    //下午出去的時間
                                    if (DateTime.Compare(time_1, Convert.ToDateTime("17:30")) > 0 && DateTime.Compare(time_1, Convert.ToDateTime("19:30")) < 0)    //DateTime.Compare(t1,t2)>0,則表示t1>t2
                                    {
                                        result = time_1.ToString("HH:mm");
                                        return result;
                                    }

                                    //若上面的時間區段沒有找到，可能是超時加班的
                                    if (DateTime.Compare(time_1, Convert.ToDateTime("19:30")) > 0 && DateTime.Compare(time_1, Convert.ToDateTime("23:59")) < 0)    //DateTime.Compare(t1,t2)>0,則表示t1>t2
                                    {
                                        result = time_1.ToString("HH:mm");
                                        return result;
                                    }

                                }


                                if (workStart.Equals("19:00"))  //夜班
                                {
                                    //夜班查兩天的數據，上班時間：查當天的    下班時間：查後一天的
                                    if (dateAndTime[0].Equals(dateStr2))
                                    {
                                        if (DateTime.Compare(time_1, Convert.ToDateTime("05:30")) > 0 && DateTime.Compare(time_1, Convert.ToDateTime("07:30")) < 0)    //DateTime.Compare(t1,t2)>0,則表示t1>t2
                                        {
                                            result = time_1.ToString("HH:mm");
                                            return result;
                                        }

                                        //若上面的時間區段沒有找到，可能是超時加班的
                                        if (DateTime.Compare(time_1, Convert.ToDateTime("07:30")) > 0 && DateTime.Compare(time_1, Convert.ToDateTime("11:59")) < 0)    //DateTime.Compare(t1,t2)>0,則表示t1>t2
                                        {
                                            result = time_1.ToString("HH:mm");
                                            return result;
                                        }
                                    }
                                        
                                }
                            }
                        }
                        #endregion
                    }


                }

            }







            return result;
        }


    }
}
