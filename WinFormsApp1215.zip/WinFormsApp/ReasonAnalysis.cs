﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WinFormsApp
{
    class ReasonAnalysis
    {
   
        public static string getResult(string timeStart, string timeEnd, string laborHour)  //工作日加班，計算工時，分析異常
        {
            //工作日加班，計算工時，分析異常
            string theLaborHour = "error";

            DateTime time1 = Convert.ToDateTime(timeStart);
            DateTime time2 = Convert.ToDateTime(timeEnd);
            TimeSpan actualHour;

            //時間取整==================================================================================
            string[] timeStart0 = timeStart.Split(':');
            string[] timeEnd0 = timeEnd.Split(':');
            if (Convert.ToInt32(timeStart0[1]) > 30)    //上班時間，往後取整
            {
                int temp = Convert.ToInt32(timeStart0[0]) + 1;
                time1 = Convert.ToDateTime(temp + ":" + "00");
            }

            else if (Convert.ToInt32(timeStart0[1]) < 30 && Convert.ToInt32(timeStart0[1]) > 0)
            {
                time1 = Convert.ToDateTime(timeStart0[0] + ":" + "30");
            }

            //===========================================================================================
            if (Convert.ToInt32(timeEnd0[1]) > 30)    //下班時間，向前取整
            {
                time2 = Convert.ToDateTime(timeEnd0[0] + ":" + "30");
            }

            else if (Convert.ToInt32(timeEnd0[1]) < 30 )
            {
                int temp = Convert.ToInt32(timeEnd0[0]) ;
                time2 = Convert.ToDateTime(temp + ":" + "00");
            }
            //=============================================================================================

            if (time1 > time2)
            {
                time2 = time2.AddDays(1);   //日期加一天
            }

            actualHour = time2 - time1; //計算時間間隔

            double min = 0;
            if (actualHour.Minutes > 30)    //加班時長以半個小時為單位
            {
                min = 0.5;
            }

            double actualOverTimeHour = actualHour.Hours + min;     //實際加班時長
            double excelOverTimeHour = 0;       //excel裡面的加班總時長

            if (laborHour.Equals("0"))
            {
                //可以刪除
            }

            if (laborHour.Contains("N"))
            {
                string[] nums = laborHour.Split(new char[2] { 'N', ':' }, StringSplitOptions.RemoveEmptyEntries);   //工作日加班
                foreach (string str in nums)
                {
                    excelOverTimeHour = excelOverTimeHour + Convert.ToDouble(str);
                }
            }

            else if (laborHour.Contains("S"))
            {
                string[] nums = laborHour.Split(new char[2] { 'S', ':' }, StringSplitOptions.RemoveEmptyEntries);   //例假日加班【這部份暫時未分析】
                foreach (string str in nums)
                {
                    excelOverTimeHour = excelOverTimeHour + Convert.ToDouble(str);
                }
            }

            //************************************************************************************
            //判斷實際加班時長與系統的加班時長是否一致
            //若一致，則無異常
            //若不一致，則需要判斷異常的原因：漏報加班、加班未進系統、超時刷卡、。。。
            //************************************************************************************
            if (actualOverTimeHour == excelOverTimeHour)
            {
                theLaborHour = "加班工時無異常";
            }

            else if(actualOverTimeHour > excelOverTimeHour)
            {
                theLaborHour = "加班工時不一致";
            }


            return theLaborHour;
        }





        public static string getResult(string timeStart1, string timeEnd1, string timeStart2, string timeEnd2, string laborHour)    
        {
            //例假日加班，計算工時，分析異常
            string theLaborHour = "error";
            #region
            DateTime time1 = Convert.ToDateTime(timeStart1);
            DateTime time2 = Convert.ToDateTime(timeEnd1);
            DateTime time3 = Convert.ToDateTime(timeStart2);
            DateTime time4 = Convert.ToDateTime(timeEnd2);
            TimeSpan actualHour;

            //時間取整==================================================================================
            string[] timeStart01 = timeStart1.Split(':');
            string[] timeEnd01 = timeEnd1.Split(':');
            string[] timeStart02 = timeStart2.Split(':');
            string[] timeEnd02 = timeEnd2.Split(':');

            if (Convert.ToInt32(timeStart01[1]) > 30)    //上班時間，往後取整
            {
                int temp = Convert.ToInt32(timeStart01[0]) + 1;
                time1 = Convert.ToDateTime(temp + ":" + "00");
            }

            else if (Convert.ToInt32(timeStart01[1]) < 30 && Convert.ToInt32(timeStart01[1]) > 0)
            {
                time1 = Convert.ToDateTime(timeStart01[0] + ":" + "30");
            }

            //===========================================================================================
            if (Convert.ToInt32(timeEnd01[1]) > 30)    //下班時間，向前取整
            {
                time2 = Convert.ToDateTime(timeEnd01[0] + ":" + "30");
            }

            else if (Convert.ToInt32(timeEnd01[1]) < 30)
            {
                int temp = Convert.ToInt32(timeEnd01[0]);
                time2 = Convert.ToDateTime(temp + ":" + "00");
            }
            //=============================================================================================
            if (Convert.ToInt32(timeStart02[1]) > 30)    //上班時間，往後取整
            {
                int temp = Convert.ToInt32(timeStart02[0]) + 1;
                time3 = Convert.ToDateTime(temp + ":" + "00");
            }

            else if (Convert.ToInt32(timeStart02[1]) < 30 && Convert.ToInt32(timeStart02[1]) > 0)
            {
                time3 = Convert.ToDateTime(timeStart02[0] + ":" + "30");
            }

            //===========================================================================================
            if (Convert.ToInt32(timeEnd02[1]) > 30)    //下班時間，向前取整
            {
                time4 = Convert.ToDateTime(timeEnd02[0] + ":" + "30");
            }

            else if (Convert.ToInt32(timeEnd02[1]) < 30)
            {
                int temp = Convert.ToInt32(timeEnd02[0]);
                time4 = Convert.ToDateTime(temp + ":" + "00");
            }

            //====================================================

            if (time1 > time2)
            {
                time2 = time2.AddDays(1);   //日期加一天
            }

            if (time3 > time4)
            {
                time2 = time2.AddDays(1);   //日期加一天
            }

            actualHour = (time2 - time1) + (time4 -time3) ; //計算時間間隔

            double min = 0;
            if (actualHour.Minutes >= 30)    //加班時長以半個小時為單位
            {
                min = 0.5;
            }

            double actualOverTimeHour = actualHour.Hours + min;     //實際加班時長
            double excelOverTimeHour = 0;       //excel裡面的加班總時長

            if (laborHour.Contains("S"))
            {
                string[] nums = laborHour.Split(new char[2] { 'S', ':' }, StringSplitOptions.RemoveEmptyEntries);   //例假日加班
                foreach (string str in nums)
                {
                    excelOverTimeHour = excelOverTimeHour + Convert.ToDouble(str);
                }
            }

            //************************************************************************************
            //判斷實際加班時長與系統的加班時長是否一致
            //若一致，則無異常
            //若不一致，則需要判斷異常的原因：漏報加班、加班未進系統、超時刷卡、。。。
            //************************************************************************************
            if (actualOverTimeHour == excelOverTimeHour)
            {
                theLaborHour = "加班工時無異常";
            }

            else if (actualOverTimeHour > excelOverTimeHour)
            {
                theLaborHour = "加班工時不一致";
            }

            #endregion

            return theLaborHour;
        }



    }
}
